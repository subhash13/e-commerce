import { useState } from "react";
const Cart = () => {
    let [item,setitem] = useState()
    return ( 
        <div className="cart">
            <h1>Cart Page</h1>
        </div>
     );
}
 
export default Cart;