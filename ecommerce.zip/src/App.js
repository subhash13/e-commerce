import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Home";
import About from "./About";
import Products from "./products";
import Contact from "./contact";
import SingleProduct from "./singleProduct";
import Cart from "./cart";
import Navbar from "./Navbar";
import { useState,useEffect } from "react";

const App = () => {
  let cartItems = []
  let [cartValue,setCartValue] = useState(0)
  let [productsData, setProducts] = useState([]);
  useEffect(() => {
      let fetchData = async () => {
          let response = await fetch('https://dummyjson.com/products')
          let data = await response.json()
          setProducts(data.products)
      }
      fetchData()
  }, [])
  return (
    <div className="App">
      <BrowserRouter>
        <Navbar data={cartValue} />
        <div className="container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/products" element={<Products data = {productsData} /> } />
            <Route path="/cart" element={<Cart />} />
            <Route path="/products/:id" element={<SingleProduct data={cartItems} data1={[cartValue,setCartValue]} />} />
          </Routes>
        </div>
      </BrowserRouter>
    </div>
  )
};

export default App;
