import { useNavigate } from "react-router-dom";
const Products = (props) => {
    let navigate = useNavigate()
    let productsData = props.data
    // console.log(productsData);
    let viewProduct = (id) => {
        navigate(`/products/${id}`)
    }
    return (
        <div className="products mt-4">
            <h1>Products Page</h1>
            <div className="product">
                {productsData.map(data => (
                    <div className="d-flex border my-3">
                        <div className="img">
                            <img style={{ cursor: "pointer" }} onClick={() => viewProduct(data.id)} width="300px" src={data.images[0]} alt="" />
                        </div>
                        <div className="p-5">
                            <h3 style={{ cursor: "pointer" }} onClick={() => viewProduct(data.id)}>{data.brand} {data.title}</h3>
                            <p>{data.rating} ⭐</p>
                            <p className="text-danger">-{data.discountPercentage}% <span className="text-dark fs-3 px-3"> ₹ {Math.round(data.price - data.price * (data.discountPercentage) / 100) * 80}</span></p>
                            <p className="text-secondary fs-6">MRP : <span className="text-secondary text-decoration-line-through fs-6">{data.price * 80}</span></p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Products;